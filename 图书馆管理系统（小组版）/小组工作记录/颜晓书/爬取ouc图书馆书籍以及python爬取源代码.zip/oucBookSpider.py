# -*- coding: utf-8 -*- 
import pymysql
import urllib.request 
import re
import csv

#写入数据到MYSQL数据库
'''
def db(name,author,publisher,publishDate,price,coden,i):
    name=str(name)
    author=str(author)
    publisher=str(publisher)
    publishDate=str(publishDate)
    price=str(price)
    coden=str(coden)
    try:
        conn = pymysql.connect(host='localhost', user='root', password='lsplant', db='oucbook', port=8088, charset='utf-8')
        cur = conn.cursor()  
        sql = "INSERT INTO library(bookName,author,publisher,publishDate,price,bookClass) VALUES (%s,%s,%s,%s,%s,%s);"
        cur.execute(sql,(name,author,publisher,publishDate,price,coden))
        conn.commit()
        print("成功添加第" + str(i) + "条图书")
        cur.close() 
        conn.close()
    except Exception as e:
        print("异常" + e)
'''
#乱码处理         
def str_jiequ(s):
    b=''
    for i in range(0,int(len(s)/8)):
        a=str((bytes(r'\u'+s[(3+i*8):(7+i*8)],"ascii")).decode("unicode_escape"))
        b=b+a
    return b

#获取书籍信息
def getInfo(url):
    html = urllib.request.urlopen(url).read().decode('utf-8')
    #书名
    name = re.compile('<dd><a href="openlink.php\?title=(.*?)>(.*?)</a>').findall(html)
    name = str_jiequ(name[0][1])
    #print ("name:"+name)
    #作者
    author = re.compile('<dd><a href="openlink.php\?author=(.*?)>(.*?)</a>').findall(html)
    author = str_jiequ(author[0][1])
    #print ("author:"+author)
    #出版社以及出版日期
    publish = re.compile(r'<dd>(.*?)</dd>').findall(html)
    publi = re.split('\:|\,',publish[1])
    publisher = str_jiequ(publi[1])
    #print("publisher:"+publisher)
    publishDate  = str_jiequ(publi[2])
    #print("publisherDate:"+publishDate)
    #书籍分类号
    coden= re.compile('<dd><a href="openlink.php\?coden=(.*?)>(.*?)</a>').findall(html)
    coden = str_jiequ(coden[0][1])
    #print ("coden:"+coden)
    #书籍价格
    price = str(publish[2])
    if price.find("/") == -1:
        price = str(0)
    else:
        price = re.split('/',price)
        price = str_jiequ(price[1])
        price = re.findall(r"\d+\.?\d*", price)[0]
        data = (name,author,publisher,publishDate,price,coden,url)
        csvfile = open('oucBook.csv', 'a')
        writer = csv.writer(csvfile)
        writer.writerow(data)
        csvfile.close()
    #print ("price:"+price)
         
    
    '''   
    db(name,author,publisher,publishDate,price,coden,i)
    except IndexError:
        print("getdb信息获取失败！")
    except Exception as e:
        print(e)
    '''   

#url处理
def geturl(start):
    url='http://222.195.226.30/opac/item.php?marc_no=0000'
    i=start
    csvfile = open('oucBook.csv', 'w')
    writer = csv.writer(csvfile)
    writer.writerow(['bookName','author','publisher','publishDate','price','bookClass','url'])
    csvfile.close()
    while i<350000:
        try:
            a="%06d"%i
            a=str(a)
            url1=url+a
            getInfo(url1)
            print(url1)
        except Exception as e:
            print("部分信息获取失败！")
        finally:
            i+=1
geturl(330000)


